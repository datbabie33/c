package bankApp;

import java.util.LinkedList;
import java.util.List;

public class bankAccountApp {

	public static void main(String[] args) {
		
		String file = "C:\\Users\\Thiago Marques\\Desktop\\Java\\BankApp\\NewBankAccounts.csv";
		List<Account> accounts = new LinkedList<Account>();
		

		
		//read csv file/create account based on that
		List<String[]> newAccHolders = utilities.CSV.read(file);
		
		for (String[] accountHolder : newAccHolders){
			String name = accountHolder[0];
			String ssn = accountHolder[1];
			String accType = accountHolder[2];
			double initDeposit = Double.parseDouble(accountHolder[3]);
			
			if (accType.equals("Savings")){
				accounts.add(new Savings(name, ssn, initDeposit));
			}
			else if(accType.equals("Checking")){
				accounts.add(new Checking(name, ssn, initDeposit));
			}
			else{
				System.out.println("Error reading file");
			}
		}
		
		
		for (Account acc : accounts){
			System.out.println("\n*************");
			acc.showInfo();
		}
	}

}
