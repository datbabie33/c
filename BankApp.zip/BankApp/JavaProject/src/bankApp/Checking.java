package bankApp;

public class Checking extends Account{
	
	//specific properties to checking
	private int cardNumber;
	private int cardPin;
	//constructor to initialize properties
	public Checking(String name, String ssn, double initDeposit){
		super(name, ssn, initDeposit);
		accNumber = "2" + accNumber;
		setCard();
	}
	
	@Override
	public void setRate(){
		rate = getBaseRate() * 0.15;
	}
	
	private void setCard(){
		cardNumber = (int)(Math.random()*Math.pow(10, 12));
		cardPin = (int)(Math.random()*Math.pow(10, 4));
	}
	//list methods
	
	public void showInfo(){
		System.out.println("\nAccount type: Checking");
		super.showInfo();
		System.out.println(" Card number: " + cardNumber + 
				"\n Card PIN: " + cardPin);
		
	}
}
