package bankApp;

public abstract class Account implements IBaseRate {
	//abstract - not creating objects from here
	
	//list common properties for savings/checking
	private String name;
	private String ssn;
	private double balance;
	protected String accNumber;
	protected double rate;
	private static int index = 10000;
	
	// constructor to set base properties/initialize accounts
	public Account(String name, String ssn, double initDeposit){
		this.name = name;
		this.ssn = ssn;
		this.balance = initDeposit;
		
		
		index++;
		this.accNumber = setAccNumber();
		setRate();
	}
	
	public abstract void setRate();
	
	private String setAccNumber(){
		String lastTwoSsn = ssn.substring(ssn.length()-2, ssn.length());
		int uniqueId = index;
		int randomNumber = (int) (Math.random() * Math.pow(10, 3));
		return lastTwoSsn + uniqueId + randomNumber;
	}
	//list common methods
	public void compound(){
		double interest = balance * (rate/100);
		balance = balance + interest;
	}
	
	public void deposit(double amount){
		balance = balance + amount;
		System.out.println("depositing $"+ amount);
		printBalance();
	}
	public void withdraw(double amount){
		balance = balance - amount;
		System.out.println("withdrawing $"+ amount);
		printBalance();
	}
	public void transfer(String where, double amount){
		balance = balance - amount;
		System.out.println("Sending $"+ amount + " to " + where);
	}
	
	public void printBalance(){
		System.out.println("New Balance: $" + balance);
	}
	
	public void showInfo(){
		System.out.println("Name: " + name +
				 			"\nAccount Number: " + accNumber + 
				 			"\nBalance: " + balance + 
				 			"\nRate: " + rate + "%");
	}

}
