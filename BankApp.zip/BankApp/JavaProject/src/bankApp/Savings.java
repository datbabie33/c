package bankApp;

public class Savings extends Account {

	//specific properties to savings
	private int safetyBoxId;
	private int safetyBoxKey;
	//constructor to initialize properties
	public Savings(String name, String ssn, double initDeposit){
		super(name, ssn, initDeposit);
		accNumber = "1" + accNumber;
		setSafetyBox();
	}
	
	@Override
	public void setRate(){
		rate = getBaseRate() - 0.25;
	}
	
	private void setSafetyBox(){
		safetyBoxId = (int) (Math.random() * Math.pow(10, 5));
		safetyBoxKey = (int) (Math.random() * Math.pow(10, 4));
	}
	
	//list methods
	public void showInfo(){
		System.out.println("\nAccount type: Savings");
		super.showInfo();
		System.out.println(" Safety deposit box ID: " + safetyBoxId + 
				"\n Safety deposit box key: " + safetyBoxKey);
		
	}
}
